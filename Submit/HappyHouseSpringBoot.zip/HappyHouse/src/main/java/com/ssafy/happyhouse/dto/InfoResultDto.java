package com.ssafy.happyhouse.dto;

import java.util.List;

public class InfoResultDto {
	private int result;
	private InfoDto info;
	private InfoDto avg;
	public int getResult() {
		return result;
	}
	public void setResult(int result) {
		this.result = result;
	}
	public InfoDto getInfo() {
		return info;
	}
	public void setInfo(InfoDto info) {
		this.info = info;
	}
	public InfoDto getAvg() {
		return avg;
	}
	public void setAvg(InfoDto avg) {
		this.avg = avg;
	}
	
	
	
	
}
